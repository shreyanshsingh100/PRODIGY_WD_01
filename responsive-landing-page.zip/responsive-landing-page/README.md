# RESPONSIVE LANDING PAGE

A Pen created on CodePen.io. Original URL: [https://codepen.io/shreyanshsingh/pen/GRVZaJL](https://codepen.io/shreyanshsingh/pen/GRVZaJL).

